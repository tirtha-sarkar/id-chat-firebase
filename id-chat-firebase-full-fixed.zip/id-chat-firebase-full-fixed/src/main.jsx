import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {
 Search,Send,Paperclip,ShieldBan,UserRound,LogOut,Menu,X,ArrowLeft,
 Bell,Copy,Image as ImageIcon,Trash2
} from "lucide-react";
import {
 watchAuth,registerUser,loginUser,logoutUser,getMyUser,ensureMyUser,findUserById,
 watchConversation,sendMessage,deleteMessage,blockUser,unblockUser,
 isBlocked,uploadChatFile,saveProfile,enablePush,listenForegroundPush,watchContacts,saveContact,removeContact
} from "./services";
import "./styles.css";

const initials=n=>(n||"?").split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();
function Avatar({u,large=false}){return <div className={"avatar "+(large?"large":"")}>{u?.photo?<img src={u.photo}/>:initials(u?.name)}</div>}

function Auth({done}){
 const [mode,setMode]=useState("login"),[name,setName]=useState(""),[email,setEmail]=useState(""),[password,setPassword]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e){e.preventDefault();setBusy(true);try{
   const u=mode==="login"?await loginUser(email,password):await registerUser({name,email,password});
   done(u);
 }catch(e){alert(e.message)}finally{setBusy(false)}}
 return <div className="auth"><form className="auth-card" onSubmit={submit}>
   <h1>💬 ID Chat</h1><p>Real-time Firebase chat</p>
   {mode==="register"&&<input placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} required/>}
   <input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
   <input type="password" placeholder="Password (6+)" value={password} onChange={e=>setPassword(e.target.value)} minLength="6" required/>
   <button disabled={busy} className="primary">{busy?"Please wait...":mode==="login"?"Login":"Create account"}</button>
   <button type="button" className="link" onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"Create new account":"Back to login"}</button>
 </form></div>
}

function Profile({me,close,setMe}){
 const [name,setName]=useState(me.name),[bio,setBio]=useState(me.bio||""),[photo,setPhoto]=useState(me.photo||"");
 function photoPick(e){const f=e.target.files?.[0];if(!f)return;if(f.size>1500000)return alert("Profile image max 1.5 MB.");const r=new FileReader();r.onload=()=>setPhoto(r.result);r.readAsDataURL(f)}
 async function save(){try{await saveProfile(me.id,{name,bio,photo});setMe({...me,name,bio,photo});close()}catch(e){alert(e.message)}}
 return <div className="overlay"><div className="modal"><div className="modal-head"><h2>Profile</h2><button onClick={close}><X/></button></div>
 <div className="profile"><Avatar u={{...me,photo}} large/><label className="upload"><ImageIcon/> Change photo<input hidden type="file" accept="image/*" onChange={photoPick}/></label></div>
 <div className="id"><b>Your User ID</b><span>{me.id}</span><button onClick={()=>navigator.clipboard?.writeText(me.id)}><Copy/></button></div>
 <label>Name<input value={name} onChange={e=>setName(e.target.value)}/></label>
 <label>Bio<textarea rows="3" value={bio} onChange={e=>setBio(e.target.value)}/></label>
 <button className="primary" onClick={save}>Save</button></div></div>
}

function Chat({me,other,onBack}){
 const [msgs,setMsgs]=useState([]),[text,setText]=useState(""),[blocked,setBlocked]=useState(false),[file,setFile]=useState(null);
 useEffect(()=>{if(!other)return;return watchConversation(me.id,other.id,setMsgs)},[me.id,other?.id]);
 useEffect(()=>{if(other)isBlocked(me.id,other.id).then(setBlocked)},[me.id,other?.id]);
 async function attach(e){const f=e.target.files?.[0];if(!f)return;try{setFile(await uploadChatFile(me.id,f))}catch(e){alert(e.message)}}
 async function send(){if(blocked||(!text.trim()&&!file))return;try{await sendMessage({from:me.id,to:other.id,text,file});setText("");setFile(null)}catch(e){alert(e.message)}}
 async function toggle(){try{if(blocked){await unblockUser(me.id,other.id);setBlocked(false)}else{await blockUser(me.id,other.id);setBlocked(true)}}catch(e){alert(e.message)}}
 return <section className="chat">
 <header><button className="mobile" onClick={onBack}><ArrowLeft/></button><Avatar u={other}/><div className="grow"><b>{other.name}</b><small>ID: {other.id} · {other.online?"🟢 Online":"Offline"}</small></div><button onClick={toggle} title="Block/Unblock"><ShieldBan/></button></header>
 {blocked&&<div className="blocked">🚫 You blocked this user. Unblock to send.</div>}
 <div className="messages">{msgs.length===0?<div className="empty">👋<b>No messages yet</b><span>Send the first message.</span></div>:msgs.map(m=><div key={m.id} className={"row "+(m.from===me.id?"mine":"")}><div className="bubble">
   {m.deleted?<i>Message deleted</i>:<>{m.file&&(m.file.type?.startsWith("image/")?<img src={m.file.url}/>:<a href={m.file.url} target="_blank">{m.file.name}</a>)}{m.text&&<div>{m.text}</div>}</>}
   {m.from===me.id&&!m.deleted&&<button className="delete" onClick={()=>deleteMessage(me.id,other.id,m.id).catch(e=>alert(e.message))}><Trash2 size={12}/></button>}
 </div></div>)}</div>
 <div className="composer"><label><Paperclip/><input hidden type="file" onChange={attach}/></label><input disabled={blocked} value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder={blocked?"Blocked":"Message..."}/><button className="send" disabled={blocked} onClick={send}><Send/></button></div>
 {file&&<div className="file-chip">📎 {file.name} <button onClick={()=>setFile(null)}>×</button></div>}
 </section>
}

function App(){
 const [me,setMe]=useState(null),[other,setOther]=useState(null),[contacts,setContacts]=useState([]),[query,setQuery]=useState(""),[found,setFound]=useState(null),[profile,setProfile]=useState(false),[menu,setMenu]=useState(false),[push,setPush]=useState(false),[authLoading,setAuthLoading]=useState(true),[profileError,setProfileError]=useState("");
 useEffect(()=>{
   let alive=true;
   const unsubscribe=watchAuth(async u=>{
     if(!alive)return;
     setAuthLoading(true);
     setProfileError("");
     if(!u){ setMe(null); setAuthLoading(false); return; }
     try {
       const x=await ensureMyUser(u.uid,u);
       if(alive) setMe(x);
     } catch(e) {
       console.error("Could not load user profile",e);
       if(alive) { setMe(null); setProfileError(e?.message||"Could not load your profile."); }
     } finally {
       if(alive) setAuthLoading(false);
     }
   });
   return ()=>{alive=false;unsubscribe();};
 },[]);
 useEffect(()=>{if(!me)return;listenForegroundPush(p=>{if(Notification.permission==="granted")new Notification(p.notification?.title||"New message",{body:p.notification?.body||"New message"})})},[me]);
 useEffect(()=>{if(!me){setContacts([]);return;} return watchContacts(me.id,setContacts)},[me?.id]);
 async function openChat(user){ if(!user||user.id===me.id)return; try{await saveContact(me.id,user); setOther(user); setFound(null); setQuery(""); setMenu(false);}catch(e){alert(e.message)} }
 async function removeSavedContact(id,e){e?.stopPropagation(); try{await removeContact(me.id,id); if(other?.id===id)setOther(null);}catch(e){alert(e.message)}}
 async function search(){if(!query.trim())return;setFound(await findUserById(query.trim()))}
 async function enable(){try{await enablePush(me.id);setPush(true);alert("Notifications enabled on this device.")}catch(e){alert(e.message)}}
 if(authLoading) return <div className="auth"><div className="auth-card"><h1>💬 ID Chat</h1><p>Loading your account...</p></div></div>;
 if(profileError) return <div className="auth"><div className="auth-card"><h1>💬 ID Chat</h1><p>Could not load your profile.</p><small>{profileError}</small><button className="primary" onClick={()=>window.location.reload()}>Retry</button><button className="link" onClick={()=>logoutUser().catch(()=>{})}>Logout</button></div></div>;
 if(!me)return <Auth done={()=>{}}/>;
 return <div className="app">
  <aside className={menu?"open":""}><div className="side-head"><b>💬 ID Chat</b><button className="mobile" onClick={()=>setMenu(false)}><X/></button><small>Your ID: {me.id}</small>
   <div className="search"><Search/><input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==="Enter"&&search()} placeholder="Search User ID"/><button onClick={search}>Find</button></div>
  </div>
  {query&&<div className="result">{found?<><Avatar u={found}/><div className="grow"><b>{found.name}</b><small>ID: {found.id}</small></div><button className="primary small" onClick={()=>openChat(found)}>Chat</button></>:<p>No user found</p>}</div>}
  <div className="contacts-section">
    <div className="section-title"><b>Saved contacts</b><span>{contacts.length}</span></div>
    {contacts.length===0?<div className="contacts-empty">Search a 6-digit ID and open a chat. The profile will be saved here automatically.</div>:contacts.map(c=><button key={c.id} className={'contact-item '+(other?.id===c.id?'active':'')} onClick={()=>openChat(c)}>
      <Avatar u={c}/><div className="grow"><b>{c.name}</b><small>ID: {c.id} · {c.online?"🟢 Online":"Offline"}</small></div><span className="remove-contact" title="Remove contact" onClick={e=>removeSavedContact(c.id,e)}>×</span>
    </button>)}
  </div>
  <div className="side-info"><p><UserRound/> {me.name}</p><button onClick={()=>setProfile(true)}><UserRound/> Profile</button><button onClick={enable}><Bell/> {push?"Notifications on":"Enable notifications"}</button><button onClick={()=>logoutUser(me.id)}><LogOut/> Logout</button></div>
  <div className="security">🔒 Firebase backend<br/><small>Realtime Firestore + Auth + Storage</small></div>
  </aside>
  {other?<Chat me={me} other={other} onBack={()=>setMenu(true)}/>:<main className="welcome"><button className="mobile menu" onClick={()=>setMenu(true)}>☰</button><div>💬<h2>Select a user</h2><p>Search by their 6-digit ID to start real-time chat.</p></div></main>}
  {profile&&<Profile me={me} setMe={setMe} close={()=>setProfile(false)}/>}
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);
