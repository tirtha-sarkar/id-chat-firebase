import {
  collection, doc, getDoc, setDoc, addDoc, updateDoc, deleteDoc,
  query, where, orderBy, onSnapshot, serverTimestamp, limit
} from "firebase/firestore";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage, getFCM, firebaseConfigured } from "./firebase";
import { getToken, onMessage } from "firebase/messaging";

export function watchAuth(cb) { return onAuthStateChanged(auth, cb); }

export async function registerUser({name,email,password}) {
  const cred = await createUserWithEmailAndPassword(auth,email,password);
  await updateProfile(cred.user,{displayName:name});
  let id = String(Math.floor(100000 + Math.random()*900000));
  while ((await getDoc(doc(db,"users",id))).exists())
    id = String(Math.floor(100000 + Math.random()*900000));
  await setDoc(doc(db,"users",id),{
    uid:cred.user.uid,id,name,email,photo:"",bio:"",online:true,createdAt:serverTimestamp()
  });
  await setDoc(doc(db,"uidMap",cred.user.uid),{userId:id});
  return {...cred.user,id};
}

export async function loginUser(email,password) {
  const cred = await signInWithEmailAndPassword(auth,email,password);
  // Profile loading is handled by watchAuth/App. Do not block login on Firestore here.
  return cred.user;
}

export async function ensureMyUser(uid, authUser = null) {
  const mapRef = doc(db, "uidMap", uid);
  const map = await getDoc(mapRef);

  if (map.exists()) {
    const id = map.data().userId;
    const userRef = doc(db, "users", id);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      const name = authUser?.displayName || "User";
      const email = authUser?.email || "";
      await setDoc(userRef, {
        uid, id, name, email, photo: "", bio: "", online: true, createdAt: serverTimestamp()
      }, { merge: true });
    } else {
      await updateDoc(userRef, { online: true });
    }
    const fresh = await getDoc(userRef);
    return fresh.exists() ? fresh.data() : null;
  }

  // Repair a user whose Auth account exists but the profile mapping was not created.
  let id = String(Math.floor(100000 + Math.random() * 900000));
  while ((await getDoc(doc(db, "users", id))).exists()) {
    id = String(Math.floor(100000 + Math.random() * 900000));
  }
  const name = authUser?.displayName || "User";
  const email = authUser?.email || "";
  await setDoc(doc(db, "users", id), {
    uid, id, name, email, photo: "", bio: "", online: true, createdAt: serverTimestamp()
  });
  await setDoc(mapRef, { userId: id });
  const snap = await getDoc(doc(db, "users", id));
  return snap.exists() ? snap.data() : null;
}

export async function logoutUser(userId) {
  if(userId) await updateDoc(doc(db,"users",userId),{online:false}).catch(()=>{});
  await signOut(auth);
}

export async function getMyUser(uid) {
  const map=await getDoc(doc(db,"uidMap",uid));
  if(!map.exists()) return null;
  const snap=await getDoc(doc(db,"users",map.data().userId));
  return snap.exists()?snap.data():null;
}


export function watchContacts(userId, cb) {
  const q = query(collection(db, "users", userId, "contacts"), orderBy("savedAt", "desc"), limit(100));
  return onSnapshot(q, s => cb(s.docs.map(d => ({ id: d.id, ...d.data() }))));
}

export async function saveContact(userId, contact) {
  await setDoc(doc(db, "users", userId, "contacts", contact.id), {
    id: contact.id,
    uid: contact.uid || "",
    name: contact.name || "User",
    email: contact.email || "",
    photo: contact.photo || "",
    bio: contact.bio || "",
    online: !!contact.online,
    savedAt: serverTimestamp()
  }, { merge: true });
}

export async function removeContact(userId, contactId) {
  await deleteDoc(doc(db, "users", userId, "contacts", contactId));
}

export async function findUserById(id) {
  const snap=await getDoc(doc(db,"users",id));
  return snap.exists()?snap.data():null;
}

export function watchConversation(a,b,cb) {
  const key=[a,b].sort().join("_");
  const q=query(collection(db,"conversations",key,"messages"),orderBy("createdAt","asc"),limit(300));
  return onSnapshot(q,s=>cb(s.docs.map(d=>({id:d.id,...d.data()}))));
}

export async function sendMessage({from,to,text,file=null}) {
  const key=[from,to].sort().join("_");
  await addDoc(collection(db,"conversations",key,"messages"),{
    from,to,text:text||"",file:file||null,deleted:false,createdAt:serverTimestamp()
  });
}

export async function deleteMessage(from,to,messageId) {
  const key=[from,to].sort().join("_");
  await updateDoc(doc(db,"conversations",key,"messages",messageId),{
    deleted:true,text:"",file:null
  });
}

export async function blockUser(me,target) {
  await setDoc(doc(db,"users",me,"blocks",target),{target,createdAt:serverTimestamp()});
}
export async function unblockUser(me,target) {
  await deleteDoc(doc(db,"users",me,"blocks",target));
}
export async function isBlocked(me,target) {
  return (await getDoc(doc(db,"users",me,"blocks",target))).exists();
}

export async function uploadChatFile(userId,file) {
  if(file.size>5*1024*1024) throw new Error("File must be 5 MB or smaller.");
  const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
  const storageRef=ref(storage,`chatFiles/${userId}/${Date.now()}_${safe}`);
  await uploadBytes(storageRef,file);
  const url=await getDownloadURL(storageRef);
  return {name:file.name,type:file.type,url};
}

export async function saveProfile(userId,data) {
  await updateDoc(doc(db,"users",userId),data);
}

export async function enablePush(userId) {
  if(!firebaseConfigured) throw new Error("Firebase config is missing.");
  const messaging=await getFCM();
  if(!messaging) throw new Error("Push messaging is not supported by this browser.");
  const permission=await Notification.requestPermission();
  if(permission!=="granted") throw new Error("Notification permission was denied.");
  const token=await getToken(messaging,{vapidKey:import.meta.env.VITE_FIREBASE_VAPID_KEY});
  if(!token) throw new Error("Could not get notification token.");
  await setDoc(doc(db,"users",userId,"tokens",btoa(token).replaceAll("/","_")),{
    token,updatedAt:serverTimestamp()
  });
  return token;
}

export async function listenForegroundPush(cb) {
  const messaging=await getFCM();
  if(!messaging) return ()=>{};
  return onMessage(messaging,cb);
}
